<?php
// ============================================================
// LUXE MART — PHP Backend (MySQL)
// File: api/index.php (Router)
// ============================================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

// ============================================================
// DATABASE CONFIG (config/db.php)
// ============================================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'your_password');
define('DB_NAME', 'luxemart');

function getDB() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            http_response_code(500);
            echo json_encode(['error' => 'DB connection failed: ' . $conn->connect_error]);
            exit;
        }
        $conn->set_charset('utf8mb4');
    }
    return $conn;
}

// ============================================================
// ROUTER
// ============================================================
$method = $_SERVER['REQUEST_METHOD'];
$path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
$segments = explode('/', $path);
$resource = $segments[1] ?? '';  // e.g. api/products → products
$id = $segments[2] ?? null;

switch ($resource) {
    case 'products':    handleProducts($method, $id);  break;
    case 'categories':  handleCategories($method, $id); break;
    case 'orders':      handleOrders($method, $id);    break;
    case 'users':       handleUsers($method, $id);     break;
    case 'auth':        handleAuth($method);           break;
    case 'cart':        handleCart($method);           break;
    case 'wishlist':    handleWishlist($method);       break;
    case 'coupons':     handleCoupons($method, $id);   break;
    case 'reviews':     handleReviews($method, $id);   break;
    case 'admin':       handleAdmin($method, $id);     break;
    case 'upload':      handleUpload();                break;
    default:
        json(['message' => 'Luxe Mart API v1.0', 'endpoints' => [
            'GET /api/products', 'POST /api/products', 'GET /api/products/{id}',
            'GET /api/categories', 'POST /api/auth/login', 'POST /api/auth/register',
            'GET /api/orders', 'POST /api/orders', 'GET /api/admin/stats'
        ]]);
}

// ============================================================
// HELPERS
// ============================================================
function json($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function body() {
    return json_decode(file_get_contents('php://input'), true) ?? [];
}

function auth() {
    $headers = getallheaders();
    $token = $headers['Authorization'] ?? '';
    $token = str_replace('Bearer ', '', $token);
    if (!$token) json(['error' => 'Unauthorized'], 401);
    $db = getDB();
    $stmt = $db->prepare("SELECT id, role FROM users WHERE token = ? AND token_expires > NOW()");
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    if (!$result) json(['error' => 'Invalid or expired token'], 401);
    return $result;
}

function adminAuth() {
    $user = auth();
    if ($user['role'] !== 'admin') json(['error' => 'Admin access required'], 403);
    return $user;
}

// ============================================================
// PRODUCTS
// ============================================================
function handleProducts($method, $id) {
    $db = getDB();
    if ($method === 'GET') {
        if ($id) {
            $stmt = $db->prepare("
                SELECT p.*, c.name as category_name, 
                       AVG(r.rating) as avg_rating, COUNT(r.id) as review_count
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                LEFT JOIN reviews r ON r.product_id = p.id
                WHERE p.id = ? AND p.status = 'active'
                GROUP BY p.id
            ");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $product = $stmt->get_result()->fetch_assoc();
            if (!$product) json(['error' => 'Product not found'], 404);
            // Get images
            $imgStmt = $db->prepare("SELECT url FROM product_images WHERE product_id = ?");
            $imgStmt->bind_param('i', $id);
            $imgStmt->execute();
            $product['images'] = $imgStmt->get_result()->fetch_all(MYSQLI_ASSOC);
            json($product);
        }
        // List products with filters
        $page = intval($_GET['page'] ?? 1);
        $limit = intval($_GET['limit'] ?? 12);
        $offset = ($page - 1) * $limit;
        $category = $_GET['category'] ?? null;
        $search = $_GET['search'] ?? null;
        $sort = $_GET['sort'] ?? 'created_at DESC';
        $min_price = floatval($_GET['min_price'] ?? 0);
        $max_price = floatval($_GET['max_price'] ?? 999999);

        $where = "p.status = 'active' AND p.price BETWEEN ? AND ?";
        $params = [$min_price, $max_price];
        $types = 'dd';
        if ($category) { $where .= " AND c.slug = ?"; $params[] = $category; $types .= 's'; }
        if ($search) { $where .= " AND (p.name LIKE ? OR p.description LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; $types .= 'ss'; }

        $validSorts = ['price ASC','price DESC','created_at DESC','avg_rating DESC'];
        $orderBy = in_array($sort, $validSorts) ? $sort : 'p.created_at DESC';

        $sql = "SELECT p.id, p.name, p.price, p.original_price, p.stock, p.badge, p.thumbnail,
                       c.name as category_name, c.slug as category_slug,
                       AVG(r.rating) as avg_rating, COUNT(r.id) as review_count
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                LEFT JOIN reviews r ON r.product_id = p.id
                WHERE $where
                GROUP BY p.id
                ORDER BY $orderBy
                LIMIT ? OFFSET ?";
        $params[] = $limit; $params[] = $offset; $types .= 'ii';

        $stmt = $db->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

        $countSql = "SELECT COUNT(DISTINCT p.id) as total FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE $where";
        $countStmt = $db->prepare($countSql);
        $countParams = array_slice($params, 0, count($params) - 2);
        $countTypes = substr($types, 0, -2);
        if ($countTypes) $countStmt->bind_param($countTypes, ...$countParams);
        $countStmt->execute();
        $total = $countStmt->get_result()->fetch_assoc()['total'];

        json(['data' => $products, 'total' => $total, 'page' => $page, 'limit' => $limit, 'pages' => ceil($total/$limit)]);
    }

    if ($method === 'POST') {
        adminAuth();
        $data = body();
        $required = ['name','price','category_id','description'];
        foreach ($required as $f) if (empty($data[$f])) json(['error' => "$f is required"], 422);
        $stmt = $db->prepare("INSERT INTO products (name, description, price, original_price, category_id, stock, badge, thumbnail, status) VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param('ssddiiiss',
            $data['name'], $data['description'], $data['price'],
            $data['original_price'] ?? null, $data['category_id'],
            $data['stock'] ?? 0, $data['badge'] ?? null,
            $data['thumbnail'] ?? null, $data['status'] ?? 'active'
        );
        $stmt->execute();
        json(['id' => $db->insert_id, 'message' => 'Product created'], 201);
    }

    if ($method === 'PUT' && $id) {
        adminAuth();
        $data = body();
        $stmt = $db->prepare("UPDATE products SET name=?, description=?, price=?, original_price=?, stock=?, badge=?, thumbnail=?, status=? WHERE id=?");
        $stmt->bind_param('ssddisss i',
            $data['name'], $data['description'], $data['price'],
            $data['original_price'], $data['stock'], $data['badge'],
            $data['thumbnail'], $data['status'], $id
        );
        $stmt->execute();
        json(['message' => 'Product updated']);
    }

    if ($method === 'DELETE' && $id) {
        adminAuth();
        $stmt = $db->prepare("UPDATE products SET status='deleted' WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        json(['message' => 'Product deleted']);
    }
}

// ============================================================
// CATEGORIES
// ============================================================
function handleCategories($method, $id) {
    $db = getDB();
    if ($method === 'GET') {
        $stmt = $db->query("SELECT c.*, COUNT(p.id) as product_count FROM categories c LEFT JOIN products p ON p.category_id = c.id AND p.status='active' GROUP BY c.id ORDER BY c.sort_order");
        json($stmt->fetch_all(MYSQLI_ASSOC));
    }
    if ($method === 'POST') {
        adminAuth(); $data = body();
        $stmt = $db->prepare("INSERT INTO categories (name, slug, icon, image, sort_order) VALUES (?,?,?,?,?)");
        $stmt->bind_param('ssssi', $data['name'], $data['slug'], $data['icon'], $data['image'], $data['sort_order'] ?? 0);
        $stmt->execute();
        json(['id' => $db->insert_id, 'message' => 'Category created'], 201);
    }
    if ($method === 'DELETE' && $id) {
        adminAuth();
        $db->query("DELETE FROM categories WHERE id=$id");
        json(['message' => 'Category deleted']);
    }
}

// ============================================================
// AUTHENTICATION
// ============================================================
function handleAuth($method) {
    $db = getDB();
    $action = $_GET['action'] ?? '';
    $data = body();

    if ($action === 'register') {
        $required = ['name','email','password'];
        foreach ($required as $f) if (empty($data[$f])) json(['error' => "$f is required"], 422);
        // Check existing
        $stmt = $db->prepare("SELECT id FROM users WHERE email=?");
        $stmt->bind_param('s', $data['email']); $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) json(['error' => 'Email already registered'], 409);
        $hash = password_hash($data['password'], PASSWORD_BCRYPT);
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
        $stmt = $db->prepare("INSERT INTO users (name, email, password, phone, token, token_expires) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param('ssssss', $data['name'], $data['email'], $hash, $data['phone'] ?? null, $token, $expires);
        $stmt->execute();
        json(['token' => $token, 'user' => ['id' => $db->insert_id, 'name' => $data['name'], 'email' => $data['email'], 'role' => 'customer']], 201);
    }

    if ($action === 'login') {
        if (empty($data['email']) || empty($data['password'])) json(['error' => 'Email and password required'], 422);
        $stmt = $db->prepare("SELECT * FROM users WHERE email=?");
        $stmt->bind_param('s', $data['email']); $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        if (!$user || !password_verify($data['password'], $user['password'])) json(['error' => 'Invalid credentials'], 401);
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
        $stmt = $db->prepare("UPDATE users SET token=?, token_expires=? WHERE id=?");
        $stmt->bind_param('ssi', $token, $expires, $user['id']); $stmt->execute();
        unset($user['password']); $user['token'] = $token;
        json($user);
    }

    if ($action === 'logout') {
        $user = auth();
        $stmt = $db->prepare("UPDATE users SET token=NULL WHERE id=?");
        $stmt->bind_param('i', $user['id']); $stmt->execute();
        json(['message' => 'Logged out']);
    }

    if ($action === 'me') {
        $user = auth();
        $stmt = $db->prepare("SELECT id,name,email,phone,role,created_at FROM users WHERE id=?");
        $stmt->bind_param('i', $user['id']); $stmt->execute();
        json($stmt->get_result()->fetch_assoc());
    }
}

// ============================================================
// ORDERS
// ============================================================
function handleOrders($method, $id) {
    $db = getDB();
    $user = auth();

    if ($method === 'GET') {
        if ($id) {
            $stmt = $db->prepare("SELECT o.*, JSON_ARRAYAGG(JSON_OBJECT('product_id',oi.product_id,'name',p.name,'qty',oi.qty,'price',oi.price)) as items FROM orders o LEFT JOIN order_items oi ON oi.order_id=o.id LEFT JOIN products p ON p.id=oi.product_id WHERE o.id=? AND (o.user_id=? OR ?) GROUP BY o.id");
            $isAdmin = $user['role']==='admin' ? 1 : 0;
            $stmt->bind_param('iii', $id, $user['id'], $isAdmin); $stmt->execute();
            $order = $stmt->get_result()->fetch_assoc();
            if (!$order) json(['error' => 'Order not found'], 404);
            $order['items'] = json_decode($order['items'], true);
            json($order);
        }
        $isAdmin = $user['role'] === 'admin';
        $sql = $isAdmin
            ? "SELECT o.*, u.name as customer_name, u.email FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC LIMIT 50"
            : "SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC";
        $stmt = $db->prepare($sql);
        if (!$isAdmin) { $stmt->bind_param('i', $user['id']); }
        $stmt->execute();
        json($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
    }

    if ($method === 'POST') {
        $data = body();
        if (empty($data['items'])) json(['error' => 'No items in order'], 422);
        $subtotal = 0;
        foreach ($data['items'] as $item) $subtotal += $item['price'] * $item['qty'];
        $shipping = $subtotal > 499 ? 0 : 49;
        $tax = round($subtotal * 0.18);
        $total = $subtotal + $shipping + $tax;
        $orderNum = 'LX' . date('Ymd') . strtoupper(substr(uniqid(), -5));
        $stmt = $db->prepare("INSERT INTO orders (user_id,order_number,subtotal,shipping,tax,total,status,payment_method,shipping_address) VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param('isddddss s',
            $user['id'], $orderNum, $subtotal, $shipping, $tax, $total,
            'pending', $data['payment_method'] ?? 'card',
            json_encode($data['shipping_address'] ?? [])
        );
        $stmt->execute();
        $orderId = $db->insert_id;
        // Insert items + update stock
        foreach ($data['items'] as $item) {
            $itemStmt = $db->prepare("INSERT INTO order_items (order_id,product_id,qty,price) VALUES (?,?,?,?)");
            $itemStmt->bind_param('iiid', $orderId, $item['product_id'], $item['qty'], $item['price']);
            $itemStmt->execute();
            $stockStmt = $db->prepare("UPDATE products SET stock = stock - ? WHERE id=?");
            $stockStmt->bind_param('ii', $item['qty'], $item['product_id']); $stockStmt->execute();
        }
        json(['id' => $orderId, 'order_number' => $orderNum, 'total' => $total, 'message' => 'Order placed successfully'], 201);
    }

    if ($method === 'PUT' && $id) {
        adminAuth(); $data = body();
        $stmt = $db->prepare("UPDATE orders SET status=?, payment_status=? WHERE id=?");
        $stmt->bind_param('ssi', $data['status'], $data['payment_status'], $id); $stmt->execute();
        json(['message' => 'Order updated']);
    }
}

// ============================================================
// USERS / PROFILE
// ============================================================
function handleUsers($method, $id) {
    $user = auth();
    $db = getDB();
    if ($method === 'PUT' && $id == $user['id']) {
        $data = body();
        $stmt = $db->prepare("UPDATE users SET name=?, phone=?, address=? WHERE id=?");
        $stmt->bind_param('sssi', $data['name'], $data['phone'], json_encode($data['address'] ?? []), $user['id']);
        $stmt->execute();
        json(['message' => 'Profile updated']);
    }
    if ($method === 'GET' && $id) {
        adminAuth();
        $stmt = $db->prepare("SELECT id,name,email,phone,role,created_at FROM users WHERE id=?");
        $stmt->bind_param('i', $id); $stmt->execute();
        json($stmt->get_result()->fetch_assoc());
    }
}

// ============================================================
// REVIEWS
// ============================================================
function handleReviews($method, $id) {
    $db = getDB();
    if ($method === 'GET') {
        $productId = $_GET['product_id'] ?? null;
        if (!$productId) json(['error' => 'product_id required'], 422);
        $stmt = $db->prepare("SELECT r.*, u.name as user_name FROM reviews r JOIN users u ON u.id=r.user_id WHERE r.product_id=? ORDER BY r.created_at DESC");
        $stmt->bind_param('i', $productId); $stmt->execute();
        json($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
    }
    if ($method === 'POST') {
        $user = auth(); $data = body();
        $stmt = $db->prepare("INSERT INTO reviews (user_id, product_id, rating, title, body) VALUES (?,?,?,?,?)");
        $stmt->bind_param('iiiss', $user['id'], $data['product_id'], $data['rating'], $data['title'], $data['body']);
        $stmt->execute();
        json(['id' => $db->insert_id, 'message' => 'Review added'], 201);
    }
    if ($method === 'DELETE' && $id) {
        adminAuth();
        $db->query("DELETE FROM reviews WHERE id=$id");
        json(['message' => 'Review deleted']);
    }
}

// ============================================================
// COUPONS
// ============================================================
function handleCoupons($method, $id) {
    $db = getDB();
    if ($method === 'GET') {
        $code = $_GET['code'] ?? null;
        if ($code) {
            $stmt = $db->prepare("SELECT * FROM coupons WHERE code=? AND status='active' AND (expiry IS NULL OR expiry > NOW()) AND (max_uses IS NULL OR used_count < max_uses)");
            $stmt->bind_param('s', $code); $stmt->execute();
            $coupon = $stmt->get_result()->fetch_assoc();
            if (!$coupon) json(['error' => 'Invalid or expired coupon'], 404);
            json($coupon);
        }
        adminAuth();
        json($db->query("SELECT * FROM coupons ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC));
    }
    if ($method === 'POST') {
        adminAuth(); $data = body();
        $stmt = $db->prepare("INSERT INTO coupons (code, type, value, min_order, max_uses, expiry) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param('ssddis', $data['code'], $data['type'], $data['value'], $data['min_order'], $data['max_uses'], $data['expiry']);
        $stmt->execute();
        json(['id' => $db->insert_id, 'message' => 'Coupon created'], 201);
    }
}

// ============================================================
// ADMIN STATS
// ============================================================
function handleAdmin($method, $action) {
    adminAuth();
    $db = getDB();
    if ($action === 'stats') {
        $stats = [
            'total_revenue' => $db->query("SELECT SUM(total) FROM orders WHERE status!='cancelled'")->fetch_row()[0] ?? 0,
            'total_orders'  => $db->query("SELECT COUNT(*) FROM orders")->fetch_row()[0],
            'total_customers' => $db->query("SELECT COUNT(*) FROM users WHERE role='customer'")->fetch_row()[0],
            'total_products' => $db->query("SELECT COUNT(*) FROM products WHERE status='active'")->fetch_row()[0],
            'pending_orders' => $db->query("SELECT COUNT(*) FROM orders WHERE status='pending'")->fetch_row()[0],
            'low_stock' => $db->query("SELECT COUNT(*) FROM products WHERE stock < 5 AND status='active'")->fetch_row()[0],
            'revenue_chart' => $db->query("SELECT DATE(created_at) as date, SUM(total) as revenue FROM orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) AND status!='cancelled' GROUP BY DATE(created_at) ORDER BY date")->fetch_all(MYSQLI_ASSOC),
            'top_products' => $db->query("SELECT p.id, p.name, p.thumbnail, SUM(oi.qty) as total_sold, SUM(oi.qty*oi.price) as revenue FROM order_items oi JOIN products p ON p.id=oi.product_id GROUP BY p.id ORDER BY total_sold DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC),
        ];
        json($stats);
    }
}

// ============================================================
// CART (Server-side optional, can use localStorage in frontend)
// ============================================================
function handleCart($method) {
    $user = auth(); $db = getDB();
    if ($method === 'GET') {
        $stmt = $db->prepare("SELECT c.*, p.name, p.price, p.thumbnail FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=?");
        $stmt->bind_param('i', $user['id']); $stmt->execute();
        json($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
    }
    if ($method === 'POST') {
        $data = body();
        $stmt = $db->prepare("INSERT INTO cart (user_id,product_id,qty) VALUES (?,?,?) ON DUPLICATE KEY UPDATE qty=qty+?");
        $stmt->bind_param('iiii', $user['id'], $data['product_id'], $data['qty'], $data['qty']);
        $stmt->execute(); json(['message' => 'Added to cart']);
    }
    if ($method === 'DELETE') {
        $data = body();
        $stmt = $db->prepare("DELETE FROM cart WHERE user_id=? AND product_id=?");
        $stmt->bind_param('ii', $user['id'], $data['product_id']); $stmt->execute();
        json(['message' => 'Removed from cart']);
    }
}

// ============================================================
// WISHLIST
// ============================================================
function handleWishlist($method) {
    $user = auth(); $db = getDB();
    if ($method === 'GET') {
        $stmt = $db->prepare("SELECT w.*, p.name, p.price, p.original_price, p.thumbnail FROM wishlist w JOIN products p ON p.id=w.product_id WHERE w.user_id=?");
        $stmt->bind_param('i', $user['id']); $stmt->execute();
        json($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
    }
    if ($method === 'POST') {
        $data = body();
        $stmt = $db->prepare("INSERT IGNORE INTO wishlist (user_id,product_id) VALUES (?,?)");
        $stmt->bind_param('ii', $user['id'], $data['product_id']); $stmt->execute();
        json(['message' => 'Added to wishlist']);
    }
    if ($method === 'DELETE') {
        $data = body();
        $stmt = $db->prepare("DELETE FROM wishlist WHERE user_id=? AND product_id=?");
        $stmt->bind_param('ii', $user['id'], $data['product_id']); $stmt->execute();
        json(['message' => 'Removed from wishlist']);
    }
}

// ============================================================
// FILE UPLOAD
// ============================================================
function handleUpload() {
    adminAuth();
    if (empty($_FILES['image'])) json(['error' => 'No file uploaded'], 422);
    $file = $_FILES['image'];
    $allowed = ['image/jpeg','image/png','image/webp'];
    if (!in_array($file['type'], $allowed)) json(['error' => 'Only JPG, PNG, WebP allowed'], 422);
    if ($file['size'] > 5 * 1024 * 1024) json(['error' => 'Max 5MB'], 422);
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $name = uniqid('img_') . '.' . $ext;
    $dest = __DIR__ . '/../uploads/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $dest)) json(['error' => 'Upload failed'], 500);
    json(['url' => '/uploads/' . $name, 'message' => 'Uploaded successfully']);
}
